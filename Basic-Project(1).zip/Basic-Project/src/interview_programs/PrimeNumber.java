package interview_programs;
import java.util.Scanner;
public class PrimeNumber {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int p=0; // counter variable p=0;
		System.out.print("Enter Number : ");
		int a=sc.nextInt();
		for(int i=2; i<a; i++) {
			if(a%i==0) {
				p=1;
			}
		}
			if(p==1) {
				System.out.print("Not a Prime Number : ");
			}
			else {
				System.out.print(a+" is prime Number");
			}
	}
	
}
