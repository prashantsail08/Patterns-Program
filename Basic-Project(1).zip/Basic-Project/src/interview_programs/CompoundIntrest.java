package interview_programs;
import java.util.Scanner;
public class CompoundIntrest {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter principle: ");
		double p=sc.nextDouble();
		System.out.print("Enter Rate of Intrest: ");
		double r=sc.nextDouble();
		System.out.print("Enter no of Time Intrest: ");
		double n=sc.nextDouble();
		System.out.print("Enter Time period: ");
		double t=sc.nextDouble();
		//double ci= p* 1+(r/n) n*t);
		double ci=p*Math.pow(1+(r/n),n*t);
		System.out.println("Compund Intresrt:"+ci);
		
	}
}
