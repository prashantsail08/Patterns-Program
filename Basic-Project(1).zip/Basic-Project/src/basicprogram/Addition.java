package basicprogram;

public class Addition {
	public static void main(String[] args) {
		int a,b,c;
		a=10;
		b=5;
		c=a+b;
		System.out.print(c);
	}

}
