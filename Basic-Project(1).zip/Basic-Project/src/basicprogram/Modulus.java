package basicprogram;

public class Modulus {
	public static void main(String[] args) {
		int a,b,c;
		a=11;
		b=5;
		c=a%b; // to find reminder use %//
		System.out.println("this is modulus");
		System.out.println("Asnwer:" +c);
	}

}
