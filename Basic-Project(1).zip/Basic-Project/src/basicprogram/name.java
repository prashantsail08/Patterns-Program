package basicprogram;
import java.util.Scanner;
public class name {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String a;
		System.out.println("Enter Your Name");
		a=sc.next();
		System.out.println("Hello " +a);
	}

}
