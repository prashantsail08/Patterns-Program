package basicprogram;
import java.util.Scanner;

public class SimpleIntrest {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		double a,r;
		int n,p;
		System.out.println("Enter Principle");
		p=sc.nextInt();
		System.out.println("Enter Rate of Intrest");
		r=sc.nextDouble();
		System.out.println("Enter Days");
		n=sc.nextInt();
		a=(p*n*r)/100;
		System.out.println("Simple Intrest =" +a);
		
	}

}
