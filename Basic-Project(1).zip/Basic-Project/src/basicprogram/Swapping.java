package basicprogram;

public class Swapping {
	public static void main(String[] RGS) {
		int a=10;
		int b=20;
		System.out.println("Before Sorting");
		System.out.println("a="+a);
		System.out.println("b="+b);
		int c=a;
		a=b;
		b=c;
		System.out.println("After Sorting");
		System.out.println("a="+a);
		System.out.println("b="+b);
		
	}
}
