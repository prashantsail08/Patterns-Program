package basicprogram;
import java.util.Scanner;
public class Fullname {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String a;
		System.out.println("Enter Your Name");
		a=sc.nextLine();
		System.out.println("Hello " +a);
	}

}