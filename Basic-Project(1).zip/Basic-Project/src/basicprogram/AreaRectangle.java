package basicprogram;
import java.util.Scanner;

public class AreaRectangle {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int l,b,a;
		System.out.println("Enter Length");
		l=sc.nextInt();
		System.out.println("Enter Breadth");
		b=sc.nextInt();
		a=l*b;
		System.out.println("Area of Rectangle:" +a);
	}

}
