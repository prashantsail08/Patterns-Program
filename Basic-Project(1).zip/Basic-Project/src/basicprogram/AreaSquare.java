package basicprogram;
import java.util.Scanner;

public class AreaSquare {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a,s;
		System.out.println("Enter Number");
		s=sc.nextInt();
		a=s*s;
		System.out.println("Area of Square:" +a);
	}

}
