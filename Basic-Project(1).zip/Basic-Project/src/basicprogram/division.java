package basicprogram;

public class division {
	public static void main(String[] args) {
		int a,b,c;
		a=10;
		b=20;
		c=a/b; //if we use \- backward slash then it will show invalid character//
		System.out.println("This is Division Program");
		System.out.println("Answer:" +c);
	}

}
