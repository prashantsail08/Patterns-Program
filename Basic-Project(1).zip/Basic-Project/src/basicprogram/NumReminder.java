package basicprogram;
import java.util.Scanner;

public class NumReminder {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double a,b,r;
		System.out.println("Enter First Number");
		a=sc.nextDouble();
		System.out.println("Enter Second Number");
		b=sc.nextDouble();
		r=a%b;
		System.out.println("Reminder is :" +r);
	}
}
