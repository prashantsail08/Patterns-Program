package basicprogram;
import java.util.Scanner;

public class AreaCircle {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		double a,r; //double- we can enter decimal
//		int r;
		System.out.println("Enter Radius");
		r=sc.nextDouble();
//		a=Math.PI*r*r; we can use Math.PI also
		a=3.14*r*r;
		System.out.println("Area of Circle:" +a);
	}

}
