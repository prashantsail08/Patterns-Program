package loops;

public class DoWhileEx3 {
	public static void main(String[] args) {
		int a=5;
		do
		{
			System.out.println(a);
			a=a+5;
		}
		while(a<=50);
	}

}
