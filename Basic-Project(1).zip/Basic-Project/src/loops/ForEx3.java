package loops;

public class ForEx3 {
	public static void main(String[] args) {
		for(int a=7; a<=70; a=a+7)
		{
			System.out.println(a);
		}
	}
}
