package loops;
import java.util.Scanner;
			//this will not print - values
public class UserpracticeOddNumber1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a,b;
		System.out.println("Enter Starting Number");
		a=sc.nextInt();
		System.out.println("Enter Ending Number");
		b=sc.nextInt();
		for(int i=a; i<=b; i++) {
			if(i%2==1) {
				System.out.print(i+" ");
			}
		}
		
		for(int i=a; i>=b; i--) {
			if(i%2==1) {
				System.out.print(i+" ");
			}
	}
}
}