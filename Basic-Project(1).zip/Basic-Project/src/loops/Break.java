package loops;

public class Break {
	public static void main(String[] args) {
		for(int i=1; i<=10; i++)
		{
			//System.out.print(i);
			if(i==5)
			{
				break; // if we use break after SOP it will print output till 5
			}			//if we use break before SOP it will print output till 4 		
			System.out.print(i);
		}
	}
}
