package loops;

public class DoWhileEx1 {
	public static void main(String[] args) {
		int a =1; //start
		do 
		{
			System.out.println(a); //print
			a=a+1; //inc/dec
		}
		while(a<=10); //end

	}
}
