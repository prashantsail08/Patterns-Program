package loops;

public class WhileEx2 {
	public static void main(String[] args) {
		int a =10; //start
		while(a>=1) //end
		{
			System.out.println(a);
			a=a-1; //increment
		}
	}
}
