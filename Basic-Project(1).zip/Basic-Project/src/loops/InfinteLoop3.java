package loops;

public class InfinteLoop3 {
	public static void main(String[] args) {
		while(true)
		{
			System.out.print("Prashant");
		}
	}
}
