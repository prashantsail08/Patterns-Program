package loops;
import java.util.Scanner;

public class UserInputDivby4 {
	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		int a;
		System.out.print("Enter Number");
		a=sc.nextInt();
		if(a%4==0) {
			System.out.print(a+"Number is divisible bt 4");
		}
		else {
			System.out.print(a+"Number is not divisible by 4");
		}
	}
}
