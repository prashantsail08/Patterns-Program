package loops;

import java.util.Scanner;

public class EvenOddUserInput {
	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		int a;
		System.out.print("Enter Number");
		a=sc.nextInt();
		if(a%2==0) {
			System.out.print(a+" Number is Even");
		}
		else {
			System.out.print(a+"Number is Odd");
		}
	}
}
