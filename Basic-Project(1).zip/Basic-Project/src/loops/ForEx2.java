package loops;

public class ForEx2 {
	public static void main(String[] args) {
		for(int a=80; a>=50; a=a-1)
		{
			System.out.println(a);
		}
	}
}
