package loops;

public class WhileEx3 {  //write table of 5 using while loop
	public static void main(String[] args) {
		int a=5;
		while(a<=50)
		{
			System.out.println(a);
			a=a+5;
		}
	}
}
