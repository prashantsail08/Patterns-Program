package loops;

public class EvenandOddNumber {
	public static void main(String[] args) {
		for(int i=5; i<=20; i++) {
			if(i%2==0) {
				System.out.println(i+" is Even");
			}
			else {
				System.out.println(i+" is Odd");
			}
		}
	}
}
