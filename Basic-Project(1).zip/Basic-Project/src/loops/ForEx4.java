package loops;

public class ForEx4 {
	public static void main(String[] args) {
		for(int a=-8; a>=-80;a=a-8)
		{
			System.out.println(a);
		}
	}
}
