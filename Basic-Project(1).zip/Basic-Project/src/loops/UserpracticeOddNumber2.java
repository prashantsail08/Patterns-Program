package loops;	// if we use this 1. 10 2. -10 it will print negative values

import java.util.Scanner;

public class UserpracticeOddNumber2 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a,b;
		System.out.println("Enter Starting Number");
		a=sc.nextInt();
		System.out.println("Enter Ending Number");
		b=sc.nextInt();
		if(a<b) {    //by using if else if condition 
		for(int i=a; i<=b; i++) {
			if(i%2!=0) {
				System.out.print(i+" ");
			}
		}
		}
		else if(a>b) {
		for(int i=a; i>=b; i--) {
			if(i%2!=0) {
				System.out.println(i+" ");
			}
	}

}
}
}
