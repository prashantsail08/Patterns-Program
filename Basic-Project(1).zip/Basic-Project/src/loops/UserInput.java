package loops;
import java.util.Scanner;
public class UserInput {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int a,b,c,d;
		System.out.println("Enter starting number");
		a=sc.nextInt();
		System.out.println("Enter End number");
		b=sc.nextInt();
		System.out.println("Enter ince number");
		c=sc.nextInt();
		System.out.println("Starting number");
		d=sc.nextInt();
		for(a=d;a<=b;a=a+c)
		{
			System.out.println(a);
		}
	}

}
