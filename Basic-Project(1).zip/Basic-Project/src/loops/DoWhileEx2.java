package loops;

public class DoWhileEx2 {
	public static void main(String[] args) {
		int a =10; //start
		do 
		{
			System.out.println(a); //print
			a=a-1; //inc/dec
		}
		while(a>=1); //end

	}
}
