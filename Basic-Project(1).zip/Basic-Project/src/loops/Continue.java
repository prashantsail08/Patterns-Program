package loops;

public class Continue {

	public static void main(String[] args) {
		for(int i=1; i<=10; i++)
		{
			//System.out.print(i);
			if(i==5)
			{
				continue; // if we use continue after SOP it will print 5 .
			}			//if we use break before SOP it will not print 5 except all will print		
			System.out.print(i);
		}
	}

}
