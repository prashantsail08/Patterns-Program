package loops;

public class ForEx5 {
	public static void main(String[] args) {
		int b;
		for(int a=1; a<=10; a=a+1)
		{
			b=a*5;
			System.out.print("5x");
			System.out.print(a);
			System.out.print("=");
			System.out.println(b);
			
		}
	}
}
