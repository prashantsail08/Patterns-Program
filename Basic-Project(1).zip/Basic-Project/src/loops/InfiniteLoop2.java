package loops;

public class InfiniteLoop2 {
	public static void main(String[] args) {
		for(;;) {
			System.out.print("Prashant");
		}
	}
}
