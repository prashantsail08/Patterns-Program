package e1;
import java.util.Scanner;
public class q12 {
public static void main(String[] args) 
{
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter Number");
	int a=sc.nextInt();
	int r=0;
	while(a!=0) 
	{
		r=r+a%10;
		a=a/10;
	}
	System.out.println("Sum : "+r);
}
}
