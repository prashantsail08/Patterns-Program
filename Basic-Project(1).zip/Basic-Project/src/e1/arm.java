package e1;
import java.util.Scanner;
public class arm {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int c=0;
		System.out.println("Enter Number");
		int a=sc.nextInt();
		int d=a;
		while(a!=0) {
			int b=a%10;
			c=c+(b*b*b);
			a=a/10;
		}
		if(c==d) {
			System.out.println("arm");
		}
		else {
			
			System.out.println("not");
		}
	}
}
