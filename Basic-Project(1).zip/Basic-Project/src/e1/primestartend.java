package e1;
import java.util.Scanner;
public class primestartend {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);

		System.out.print("Enter Starting Number : ");
		int s=sc.nextInt();
		System.out.print("Enter Ending Number : ");
		int e=sc.nextInt();

		for(int a=s; a<=e; a++) {
			int p=0;
			for(int i=2; i<a; i++) {
				if(a%i==0) {
					p=1;
				}
			}
			if(p==0) {
				System.out.println("Even Number : "+a);
			}

		}
	}	
}
