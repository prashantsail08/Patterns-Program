package e1;
import java.util.Scanner;
public class q1 {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("enter 1");
		int a=sc.nextInt();
		System.out.println("enter 2");
		int b=sc.nextInt();
		System.out.println("enter 3");
		int c=sc.nextInt();
		int d=0;
		d=a;
		a=b;
		b=c;
		c=d;
		d=a+b+c;
		System.out.println(d);
		
	}
}
