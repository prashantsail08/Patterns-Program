package patterns;

public class PatternsEx2 {
	public static void main(String[] args) {
		for(int a=1; a<=5; a++) {
			System.out.println("*");
		}
	}
}
