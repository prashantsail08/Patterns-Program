package patterns;

public class PatternsEx1 {
	public static void main(String[] args) {
		for (int a=1; a<=5; a++)
		{
		System.out.print("*");
		}
	}
}
