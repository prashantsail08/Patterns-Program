package patterns;

public class PatternsEx13 {
	public static void main( String[] args) {
		int a=4;
		for(int i=1; i<=5; i++) {
			for(int k=i; k<=5; k++) {
				System.out.print(" ");
			}
			for(int j=1; j<=i; j++) {
				System.out.print(a+" ");
				a=a+4;
			}
			System.out.println();
		}
	}
}
