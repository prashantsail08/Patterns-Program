package patterns;

public class Pattern1212 
{
	public static void main(String[] args) {
		for(int i=1; i<=5; i++) 
		{
			for(int k=i; k<=5; k++) 
			{
				System.out.print(" ");
			}
			
			
			for(int j=5; j<=5; j++) 
			{
				System.out.print("*"); 


			}
			
			
			for(int k=1; k<=i; k++) 
			{
				System.out.print(" ");
			}
			


			for(int j=5; j<=7; j++) 
			{
				System.out.print("*"); 


			}
			

			System.out.println();
			}
		}
	}

