package patterns;

public class SpaceString {
	public static void main(String k[]) {
		String a="Prashant123@ #$%^&*sail";
		System.out.print(a);
	}
}
