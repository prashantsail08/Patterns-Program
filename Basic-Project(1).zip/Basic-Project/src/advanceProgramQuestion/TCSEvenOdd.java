package advanceProgramQuestion;
import java.util.Scanner;
public class TCSEvenOdd 
{
	public static void main(String[] args) 
	{
		Scanner sc= new Scanner(System.in);
		System.out.print("Entr First Number");
		int a=sc.nextInt();
		System.out.print("Enter Second Number");
		int b=sc.nextInt();
		if(a<b) 
		{
			for(int i=a; i<=b; i++) 
			{
				if(i%2!=0) 
				{
					System.out.print(i+" ");
				}
			}
		}
		else if(a>b) 
		{
			for(int i=a; i>=b; i--) 
			{
				if(i%2!=0) 
				{
					System.out.print(i+" ");
				}
			}
		}
	}
}
