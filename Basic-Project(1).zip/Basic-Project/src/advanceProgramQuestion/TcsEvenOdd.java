package advanceProgramQuestion;
import java.util.Scanner; // if First NUmber is big and Second Number is  Less 
public class TcsEvenOdd 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.print("Entr First Number");
		int a=sc.nextInt();
		System.out.print("Enter Second Number");
		int b=sc.nextInt();
		for(int i=a; i<=b; i++) 
		{
			if(a%2==1) 
			{
				System.out.print(i+" ");
			}
		}
		for(int i=a; i>=b; i--) 
		{
			if(i%2==1) 
			{
				System.out.print(i+" ");
			}
		}
	}
}
