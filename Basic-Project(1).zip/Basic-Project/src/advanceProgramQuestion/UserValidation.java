package advanceProgramQuestion;
import java.util.Scanner;
public class UserValidation 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);

		int a=1;
		for(int i=1; i>0; i++)
		{
			System.out.print("Enter Username");
			int u=sc.nextInt();
			System.out.print("Enter Password");
			int p=sc.nextInt();
			if(u==123 && p==456) 
			{
				System.out.print("Wlcome");
				break;

			}
			else
			{
				System.out.println("Invalid Enter Again");
				a++;
			}
			if(a>3) 
			{
				System.out.println("Attemp Over");
				break;


			}
		}
	}
}