package advanceProgramQuestion;

public class Highest2Array {
public static void main(String[] args) {
	int arr[]= {1,2,3,4,5,6,7};
	int max=arr[0];
	int max2=arr[0];
	for(int i=0; i<arr.length; i++)
	{
		if(max < arr[i]&& arr[i]%2==0)
		{
			max=arr[i];
		}
	}
	System.out.println("Maximum : "+max);
	
	for(int i=0; i<arr.length; i++)
	{
		if(max2 < arr[i] && arr[i] < max && arr[i]%2==0)
		{
			max2=arr[i];
		}
	}
	System.out.println("Second highest : "+max2);
}
}
