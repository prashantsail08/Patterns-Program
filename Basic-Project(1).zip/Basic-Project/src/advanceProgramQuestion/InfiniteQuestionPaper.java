package advanceProgramQuestion;
import java.util.Scanner;
public class InfiniteQuestionPaper 
{
	public static void main(String[] args) 
	{
		Scanner sc= new Scanner(System.in);
		while(true) 
		{
			System.out.println("Enter Number");
			int a=sc.nextInt();
			if(a%2==0) 
			{
				System.out.println("Valid");
				break;
			}
			else 
			{
				System.out.print("Invalid");
			}
		}
	}
}
