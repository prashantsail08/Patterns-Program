package advanceProgramQuestion;

public class ForLoopTrick {
	public static void main(String[] args) {
		int i=0;
		for(i=10; i<=20; i++);
		{
			System.out.println(i);
		}
	}
}

