package conditions;
import java.util.Scanner;

public class Nestedif {
	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		int a,b;
		System.out.println("Enter Age");
		a=sc.nextInt();
		if(a>=18) {
			System.out.println("Enter Number of Vaccine");
			b=sc.nextInt();
	
			if(b==2)
			{
				System.out.println("Eligible for Train Pass");
			}
			else
			{
				System.out.println("Your Age is Valid but your not Fully Vaccinated");
			}
		}
		else
		{
			System.out.println("Age Invalid");
		}
		
	}
}
