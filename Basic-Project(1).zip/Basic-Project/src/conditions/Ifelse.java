package conditions;
import java.util.Scanner;

public class Ifelse {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a;
		System.out.println("Enter Your Age");
		a=sc.nextInt();
		if(a>=17)
		{
			System.out.println("Welcome to vote");
		}
		else
		{
			System.out.println("you are not ELIGIBLE vote");
		}
	}
}
