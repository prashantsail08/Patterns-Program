package conditions;
import java.util.Scanner;

public class IfEx1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a;
		System.out.println("Enter Age");
		a=sc.nextInt();
		if(a>=18)
		{
			System.out.println("Welcome to Vote");
		}
		
	}
}
