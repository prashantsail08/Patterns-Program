package conditions;
import java.util.Scanner;

public class IfEx2 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a;
		System.out.println("Enter Age");
		a=sc.nextInt();
		if(a<=12)
		{
			System.out.println("Welcome to Kinder Garden");
		}
	}

}
