package conditions;
import java.util.Scanner;

public class IfelseEx2 {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int a;
		System.out.println("Enter Number");
		a=sc.nextInt();
		if(a>9)
		{
			System.out.println("Number is Positive");
		}
		else
		{
			System.out.println("Number is Negative");
		}
	}
}
