package conditions;
import java.util.Scanner;
public class LadderEx2 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int a;
		System.out.println("Enter Your Numbder");
		a=sc.nextInt();
		if(a>=90 && a<=100) {
			System.out.println("Merit");
		}
		else if(a>=75 && a<=89) {
			System.out.println("Distinction");
		}
		else if(a>=60 && a<=74) {
			System.out.println("First Class");
		}
		else if(a>=35 && a<=59) {
			System.out.println("Pass");
		}
		else if(a<35) {
			System.out.println("Fail");
		}
		else {
			System.out.println("Enter Number From 0 to 100");
		}
	}

}
