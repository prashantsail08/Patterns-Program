package conditions;
import java.util.Scanner;

public class Nestedif2 {
	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
		int a,b;
		System.out.println("Enter Marks");
		a=sc.nextInt();
		if(a>=35)
		{
			System.out.println("Enter Passing Year");
			b=sc.nextInt();
			if(b==2022) {
				System.out.println("Welcome to Job Fair");
			}
			else
			{
				System.out.println("Only Fresher Candidates can apply");
			}
		}
		else
		{
			System.out.println("Your Marks are not enough");
		}
	}		
}
