package pratice;
import java.util.Scanner;
public class prime {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);

		System.out.print("Enter Number : ");
		int first=sc.nextInt();
		System.out.print("Enter Number : ");
		int end=sc.nextInt();
		
		for(int a=first; a<=end; a++) {
			int p=0; // counter variable p=0;
			for(int i=2; i<a; i++) {
				if(a%i==0) {
					p=1;
				}
			}
			if(p==0) {
				System.out.println(a);
			}

		}
	}	
}
