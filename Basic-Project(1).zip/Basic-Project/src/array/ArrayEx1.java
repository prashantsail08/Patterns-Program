package array;

public class ArrayEx1 
{
	public static void main(String[] args)
	{
		int arr[]=new int[3];
		arr[0]=10;
		arr[2]=30;
		arr[1]=20;
		System.out.print(arr[0]);
		System.out.print(arr[1]);
		System.out.print(arr[2]);
		//System.out.print(arr[5]); if this index is not use in array then it will give this error
	}
}
