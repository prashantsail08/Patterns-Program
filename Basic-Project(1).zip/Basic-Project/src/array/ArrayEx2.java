package array;

public class ArrayEx2 {
	public static void main(String[] args) {
		String arr[] = new String[5];
		arr[0]="Prashant";
		arr[1]="Shubham";
		arr[2]="Pratik";
		arr[3]="Rohit";
		arr[4]="Virat";
		
		System.out.println(arr[0]);
		System.out.println(arr[1]);
		System.out.println(arr[2]);
		System.out.println(arr[3]);
		System.out.println(arr[4]);
	}
}
