package array;
import java.util.Scanner;
public class ArrayEx4usingFor
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int arr[]=new int[5];
		System.out.print("Enter 5 Number");
		for(int i=0; i<5; i++)
		{
			arr[i]=sc.nextInt();
		}
		System.out.println("Array List:");
		for(int i=0; i<5; i++)
		{
			System.out.println(arr[i]);
		}
	}
}
